"""
Dashboard Views Package
Imports all views from views.py file and integration module
"""

# Import all views from the main views.py file at dashboard level
import sys
import os

# Add parent directory to path to import from views.py
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import everything from dashboard.views module (the views.py file)
# This makes all views available when someone does: from dashboard.views import X
try:
    from dashboard.views import *
except ImportError:
    # If views.py doesn't exist, that's okay
    pass

# Import integration views from this package
from .integration import (
    SyncHealthView,
    TransactionSyncView,
    CustomerSyncView,
    CustomerBatchSyncView,
)

__all__ = [
    'SyncHealthView',
    'TransactionSyncView', 
    'CustomerSyncView',
    'CustomerBatchSyncView',
]
